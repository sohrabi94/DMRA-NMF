

function L = graph_laplacian(W)
    d = sum(W,2);
    D = spdiags(d,0,size(W,1),size(W,1));
    L = D - W;
end