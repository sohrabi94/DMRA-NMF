function [W, H] = update_factors(Mmix, W, H)

    H = H .* ((Mmix' * W) ./ max((H * (W' * W)), 1e-9));
    W = W .* ((Mmix * H) ./ max((W * (H' * H)), 1e-9));
end
