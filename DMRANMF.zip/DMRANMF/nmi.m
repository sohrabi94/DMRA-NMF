function val = nmi(L1, L2)
% Normalized Mutual Information between two label assignments
% Inputs: L1 - true labels
%         L2 - predicted labels
% Output: val - NMI value in [0,1]

L1 = L1(:); 
L2 = L2(:);
n = length(L1);

if length(L2) ~= n
    error('Label vectors must have the same length.');
end

classes1 = unique(L1);
classes2 = unique(L2);

% Compute mutual information
MI = 0;
for i = 1:length(classes1)
    for j = 1:length(classes2)
        p_ij = sum(L1 == classes1(i) & L2 == classes2(j)) / n;
        if p_ij > 0
            p_i = sum(L1 == classes1(i)) / n;
            p_j = sum(L2 == classes2(j)) / n;
            MI = MI + p_ij * log(p_ij / (p_i * p_j));
        end
    end
end

% Compute entropies
p1 = histcounts(L1, length(classes1)) / n;
p2 = histcounts(L2, length(classes2)) / n;
H1 = -sum(p1 .* log(p1 + eps));
H2 = -sum(p2 .* log(p2 + eps));

% Normalized Mutual Information
val = MI / sqrt(H1 * H2 + eps);
end
