function Mmix = build_mmix(A, BM, alpha)
    Mmix = (1 - alpha) * A;
    m = length(BM);
    gamma = ones(1, m) / m;
    for i = 1:m
        Mmix = Mmix + alpha * gamma(i) * BM{i};
    end
end
