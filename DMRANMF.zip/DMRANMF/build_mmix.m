

function Mmix = build_mmix(A, BM, alpha)
    m = numel(BM);
    gamma = ones(1,m) / max(m,1);
    Mmix = (1 - alpha) * A;
    for i = 1:m
        Mmix = Mmix + alpha * gamma(i) * BM{i};
    end
    Mmix = max((Mmix + Mmix')/2, 0);
end