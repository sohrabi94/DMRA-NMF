function [U, S, Psi, info] = update_factors_dmra(Mmix, U, S, Lmix, params)


    if ~isfield(params,'updateExp'), params.updateExp = 0.25; end
    if ~isfield(params,'lambda'), params.lambda = 0.1; end
    if ~isfield(params,'mu'), params.mu = 0.5; end
    if ~isfield(params,'enforceDiagonalS'), params.enforceDiagonalS = true; end
    if ~isfield(params,'epsVal'), params.epsVal = 1e-12; end

    epsVal = params.epsVal;
    updateExp = params.updateExp;
    lambda = params.lambda;
    mu = params.mu;

   
    Psi = U{1};
    for ii = 2:length(U)
        Psi = Psi * U{ii};
    end
   
    Psi = max(Psi, epsVal);


    PTP = Psi' * Psi;                      
    numS = Psi' * (Mmix * Psi);              
    denS = PTP * S * PTP;
    OffMask = ones(size(S)) - eye(size(S));
    denS = denS + mu * (OffMask .* S) + epsVal;

    ratioS = numS ./ denS;
    S = S .* (ratioS .^ updateExp);
    S = max(S, epsVal);

    if params.enforceDiagonalS
        S = diag(diag(S));
    end


    numP = Mmix * (Psi * S);
    denP = (Psi * S * (Psi' * Psi) * S) + lambda * (Lmix * Psi) + epsVal;

    ratioP = numP ./ denP;
    Psi = Psi .* (ratioP .^ updateExp);
    Psi = max(Psi, epsVal);


    Lnum = length(U);
    layerSizes = zeros(1,Lnum);
    layerSizes(1) = size(U{1},2);
    for ii = 2:Lnum
        layerSizes(ii) = size(U{ii},2);
    end

    for l = 1:Lnum
      
        if l == 1
            A = eye(size(U{1},1));
        else
            A = U{1};
            for p = 2:(l-1), A = A * U{p}; end
        end
       
        if l == Lnum
            B = eye(size(U{Lnum},2));
        else
            B = U{l+1};
            for p = (l+2):Lnum, B = B * U{p}; end
        end
      
        numer = (A' * Psi * B');
        denom = (A' * A) * U{l} * (B * B') + epsVal;
     
        ratioU = numer ./ denom;
        U{l} = U{l} .* (ratioU .^ updateExp);
        U{l} = max(U{l}, epsVal);
    end

 
    Psi = U{1};
    for ii = 2:length(U)
        Psi = Psi * U{ii};
    end
    Psi = max(Psi, epsVal);

  
    approx = Psi * S * Psi';
    reconErr = norm(Mmix - approx, 'fro')^2;
    lapReg = lambda * trace(Psi' * (Lmix * Psi));
    offdiagS = S - diag(diag(S));
    diagPen = mu * norm(offdiagS,'fro')^2;
    obj = reconErr + lapReg + diagPen;

    info.obj = obj;
    info.reconErr = reconErr;
    info.lapReg = lapReg;
    info.diagPen = diagPen;
    info.ratioS = max(ratioS(:));
    info.ratioP = max(ratioP(:));

end
