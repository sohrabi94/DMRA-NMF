clear; clc; rng(42);
load('dolphin.mat');  

params.alpha = 0.4;
params.maxIter = 200;
params.k = 2;
params.tol = 1e-5;

[W, H, metrics] = dmranmf(A, params, labels);
disp(metrics);
