

function BM = construct_motif_matrix(A, numSamples)
    sizes = [3,4,5];
    m = length(sizes);
    BM = cell(1,m);
    for i = 1:m
        BM{i} = random_walk_graphlets(A, sizes(i), numSamples);
    end
end