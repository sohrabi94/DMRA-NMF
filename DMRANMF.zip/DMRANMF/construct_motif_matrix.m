function BM = construct_motif_matrix(A)

    numSamples = 5000;
    sizes = [3, 4, 5];
    for i = 1:length(sizes)
        BM{i} = random_walk_graphlets(A, sizes(i), numSamples);
    end
end
