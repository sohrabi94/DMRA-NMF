function metrics = evaluate_metrics(true_labels, pred_labels)
    metrics.ACC = clustering_acc(true_labels, pred_labels);
    metrics.NMI = nmi(true_labels, pred_labels);
    metrics.ARI = rand_index(true_labels, pred_labels);
end
