function [W, H] = normalize_factors(W, H)
    % Normalize columns of W and H to unit length
    norms = sqrt(sum(W.^2, 1)) + eps;
    W = W ./ norms;
    H = H ./ norms;
end
