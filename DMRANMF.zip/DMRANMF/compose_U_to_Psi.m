
function X = compose_U_to_Psi(Ucell)
    X = Ucell{1};
    for i = 2:length(Ucell)
        X = X * Ucell{i};
    end
end