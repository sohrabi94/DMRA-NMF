function [U, S, metrics, info] = dmranmf_deep_full(A, labels, params)
    % ---------- param defaults & checks ----------
    if ~isfield(params,'k'), error('params.k required'); end
    if ~isfield(params,'layerSizes')
        params.layerSizes = [params.k]; % trivial single layer
    end
    if params.layerSizes(end) ~= params.k
        error('Last element of layerSizes must equal params.k');
    end
    fn = @(f,d) ifelse(isfield(params,f), params.(f), d);
    params.alpha = fn('alpha', 0.4);
    params.lambda = fn('lambda', 0.1);
    params.mu = fn('mu', 0.5);
    params.maxIter = fn('maxIter', 200);
    params.tol = fn('tol', 1e-5);
    params.numSamples = fn('numSamples', 5000);
    params.updateExp = fn('updateExp', 0.25);
    if ~isfield(params,'enforceDiagonalS'), params.enforceDiagonalS = true; end

    n = size(A,1);
    if size(A,1) ~= size(A,2), error('A must be square'); end

   
    BM = construct_motif_matrix(A, params.numSamples);
    Mmix = build_mmix(A, BM, params.alpha);
    Mmix = max((Mmix + Mmix')/2, 0); 
    Lmix = graph_laplacian(Mmix);

    
    layerSizes = params.layerSizes;
    L = length(layerSizes);
    U = cell(1,L);
   
    prevDim = n;
    for l = 1:L
        r = layerSizes(l);
        U{l} = max(0.1*rand(prevDim, r), 1e-6);
        prevDim = r;
    end
    
    k = params.k;
    S = diag(0.5 + 0.1*rand(k,1));
    S = max(S, eps);

  
    composePsi = @() compose_U_to_Psi(U);

    prevObj = [];
    info.obj = zeros(params.maxIter,1);
    for it = 1:params.maxIter
     
        Psi = composePsi(); 

       
        PTP = Psi' * Psi;            
        numS = Psi' * Mmix * Psi;    
        denS = PTP * S * PTP;       
        
        OffMask = ones(k) - eye(k);
        denS = denS + params.mu * (OffMask .* S);
        ratioS = numS ./ (denS + eps);
        S = S .* (ratioS .^ params.updateExp);
        S = max(S, eps);
        if params.enforceDiagonalS
            S = diag(diag(S));
        end

        
        numP = Mmix * Psi * S;
        denP = (Psi * S * (Psi' * Psi) * S) + params.lambda * (Lmix * Psi) + eps;
        ratioP = numP ./ denP;
        Psi = Psi .* (ratioP .^ params.updateExp);
        Psi = max(Psi, eps);


        for l = 1:L
    
            if l == 1
                A = eye(n);
            else
                A = U{1};
                for p = 2:(l-1), A = A * U{p}; end
            end
            if l == L
                B = eye(layerSizes(L));
            else
                B = U{l+1};
                for p = (l+2):L, B = B * U{p}; end
            end

            numer = (A' * Psi * B');
            denom = (A' * A) * U{l} * (B * B') + eps;
            U{l} = U{l} .* ( (numer ./ denom) .^ params.updateExp );
            U{l} = max(U{l}, eps);
        end

       
        norms = sqrt(sum(Psi.^2,1)) + eps;
        Psi = Psi ./ norms;
        S = S .* (norms' * norms);

      
        Psi = compose_U_to_Psi(U);

     
        reconErr = norm(Mmix - Psi * S * Psi', 'fro')^2;
        lapReg = params.lambda * trace(Psi' * (Lmix * Psi));
        offdiagS = S - diag(diag(S));
        diagPen = params.mu * norm(offdiagS, 'fro')^2;
        currObj = reconErr + lapReg + diagPen;
        info.obj(it) = currObj;

      
        if ~isempty(prevObj)
            relchg = abs(currObj - prevObj) / (prevObj + eps);
            if relchg < params.tol
                info.iter = it;
                fprintf('Converged at iter %d (relchg=%.2e)\n', it, relchg);
                break;
            end
        end
        prevObj = currObj;

 
        if mod(it,20) == 0
            fprintf('Iter %d: obj=%.6e\n', it, currObj);
        end
    end

  
    Psi = compose_U_to_Psi(U);

  
    opts = statset('MaxIter',200);
    pred = kmeans(Psi, params.k, 'Replicates',10, 'Options', opts);

    metrics = evaluate_metrics(labels, pred);
    info.finalObj = currObj;

   
end