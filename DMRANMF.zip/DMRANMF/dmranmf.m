function [W, H, metrics] = dmranmf(A, params, labels)

    BM = construct_motif_matrix(A);

  
    Mmix = build_mmix(A, BM, params.alpha);

    
    [n, ~] = size(A);
    k = params.k;
    W = rand(n, k); H = W;


    for t = 1:params.maxIter
        [W, H] = update_factors(Mmix, W, H);
        [W, H] = normalize_factors(W, H);
        if check_convergence(W, H, params.tol), break; end
    end

  
    pred = kmeans(W, k);
    metrics = evaluate_metrics(labels, pred);
end
