function flag = check_convergence(W, H, tol)
    persistent prev;
    if isempty(prev), prev = W * H'; flag = false; return; end
    diff = norm(W * H' - prev, 'fro') / norm(prev, 'fro');
    flag = diff < tol;
    prev = W * H';
end
