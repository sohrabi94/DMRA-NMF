
function M = random_walk_graphlets(A, sz, numSamples)
    n = size(A,1);
    M = sparse(n,n);
    if numSamples <= 0, return; end
    for s = 1:numSamples
        v = randi(n);
        nodes = v;
        for step = 1:sz-1
            nbrs = find(A(v,:));
            if isempty(nbrs), break; end
            v = nbrs(randi(length(nbrs)));
            nodes(end+1) = v;
        end
        ln = length(nodes);
        for i = 1:ln
            for j = i+1:ln
                M(nodes(i), nodes(j)) = M(nodes(i), nodes(j)) + 1;
                M(nodes(j), nodes(i)) = M(nodes(j), nodes(i)) + 1;
            end
        end
    end
    maxv = max(M(:));
    if isempty(maxv) || maxv == 0
        return;
    end
    M = M / (maxv + eps);
end
