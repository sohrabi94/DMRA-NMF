function M = random_walk_graphlets(A, sz, numSamples)
    % Simplified motif matrix using random walk sampling
    n = size(A, 1);
    M = sparse(n, n);
    for s = 1:numSamples
        v = randi(n);
        nodes = v;
        for step = 1:sz-1
            nbrs = find(A(v,:));
            if isempty(nbrs), break; end
            v = nbrs(randi(length(nbrs)));
            nodes = [nodes, v];
        end
        for i = 1:length(nodes)
            for j = i+1:length(nodes)
                M(nodes(i), nodes(j)) = M(nodes(i), nodes(j)) + 1;
                M(nodes(j), nodes(i)) = M(nodes(j), nodes(i)) + 1;
            end
        end
    end
    M = M / max(M(:) + eps);
end