
function y = ifelse(cond, a, b)
    if cond, y = a; else y = b; end
end
