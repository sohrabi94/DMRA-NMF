function acc = clustering_acc(true_labels, pred_labels)

    [~, ~, true_labels] = unique(true_labels);
    [~, ~, pred_labels] = unique(pred_labels);
    D = max(max(true_labels), max(pred_labels));


    cost = zeros(D);
    for i = 1:D
        for j = 1:D
            cost(i, j) = sum(true_labels == i & pred_labels == j);
        end
    end


    [~, assignment] = max(cost, [], 2);


    correct = 0;
    for i = 1:D
        correct = correct + cost(i, assignment(i));
    end
    acc = correct / length(true_labels);
end
